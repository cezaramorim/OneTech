// === Helper robusto: suporta id ou pk ===
function getObjId(obj) {
  return obj?.id ?? obj?.pk ?? null;
}

function getTanquesFromContext() {
  const raw = window.DJANGO_CONTEXT?.tanques;
  const arr = Array.isArray(raw) ? raw : [];

  // Normaliza pk -> id (mantém compatibilidade com qualquer fonte)
  return arr.map(t => ({
    ...t,
    id: t.id ?? t.pk,   // <-- chave definitiva
  }));
}

function resolveTanqueSelect() {
  // Tenta localizar o SELECT original (Select2 sempre mantém ele escondido no DOM)
  const candidates = [
    '#id_tanque',
    'select[name="tanque"]',
    'select[name="tanque_id"]',
    'select[data-role="tanque"]',
    'select.tanque-select',
  ];

  for (const sel of candidates) {
    const el = document.querySelector(sel);
    if (el) return el;
  }

  // fallback: tenta achar qualquer select com "tanque" no name/id
  const fallback = Array.from(document.querySelectorAll('select'))
    .find(s => /tanque/i.test(s.name || '') || /tanque/i.test(s.id || ''));
  return fallback || null;
}

function hasSelect2() {
  return !!(window.jQuery && window.jQuery.fn && window.jQuery.fn.select2);
}

function safeDestroySelect2($el) {
  try {
    if ($el && $el.length && $el.hasClass("select2-hidden-accessible")) {
      $el.select2("destroy");
    }
  } catch (err) {
    // silent fail
  }
}

/**
 * Aplica Select2 com configurações seguras p/ layouts com overflow (cards, AJAX, etc.)
 * - dropdownParent no body evita truncamento/corte
 * - width 100% mantém consistência
 * - theme bootstrap-5 mantém visual do seu projeto
 */
function applySelect2Stable($el, extraOptions = {}) {
  if (!hasSelect2()) return;

  const $ = window.jQuery;
  const $jq = ($el instanceof $) ? $el : $( $el );

  if (!$jq.length) return;

  safeDestroySelect2($jq);

  const baseOptions = {
    theme: "bootstrap-5",
    width: "100%",
    dropdownParent: $(document.body)
  };

  $jq.select2({ ...baseOptions, ...extraOptions });
}


// === Ajuste: atualizarChips tolerante a id/pk ===
function atualizarChips(tanqueId) {
  console.log('[Debug] atualizarChips: Recebeu tanqueId:', tanqueId);

  const tanques = Array.isArray(window.DJANGO_CONTEXT?.tanques) ? window.DJANGO_CONTEXT.tanques : [];
  if (!tanqueId) {
    document.querySelectorAll('[data-chip]').forEach(chip => chip.textContent = '--');
    return;
  }

  const tanque = tanques.find(t => String(getObjId(t)) === String(tanqueId));
  console.log('[Debug] Tanque encontrado no contexto:', tanque);

  if (!tanque) return;

  // Exemplo (ajuste conforme seus chips reais):
  const chipNome = document.querySelector('[data-chip="tanque-nome"]');
  if (chipNome) chipNome.textContent = tanque.nome ?? '--';

  const chipStatus = document.querySelector('[data-chip="tanque-status"]');
  if (chipStatus) chipStatus.textContent = tanque.status_nome ?? '--';

  const chipOcup = document.querySelector('[data-chip="tanque-ocupacao"]');
  if (chipOcup) chipOcup.textContent = (tanque.ocupacao_percentual ?? '--') + '%';
}


// --- HELPER: bindTanqueChange (nativo + Select2) ---
function bindTanqueChange(tanqueSelect, page) {
  const handler = () => {
    const val = (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2)
      ? window.jQuery(tanqueSelect).val()  // quando Select2 está aplicado
      : tanqueSelect.value;

    tanqueSelect.dataset.prev = val || '';
    if (typeof atualizarChips === 'function') {
      atualizarChips(val || '', page);
    }
  };

  // Limpa binds nativos anteriores e religa
  tanqueSelect.removeEventListener('change', handler);
  tanqueSelect.addEventListener('change', handler);

  // Liga eventos do Select2, se disponível (com namespace para evitar duplicidade)
  if (window.jQuery && window.jQuery.fn && window.jQuery.fn.select2) {
    const $sel = window.jQuery(tanqueSelect);
    $sel.off('select2:select.selectChips select2:clear.selectChips select2:open.selectChips');

    $sel.on('select2:select.selectChips', handler);
    $sel.on('select2:clear.selectChips', handler);

    // Ao abrir o dropdown, injeta classe para dark mode no dropdown
    $sel.on('select2:open.selectChips', () => {
      const data = $sel.data('select2');
      if (data && data.$dropdown) {
        data.$dropdown.addClass('select2-dark'); // classe nossa pro tema escuro
      }
    });
  }
}

(function () {
  const PAGE_SELECTOR = '[data-page="povoamento-lotes"]';
  const SELECT2_SELECTOR = '.select2-povoamento';
  const SELECT2_BASE_CONFIG = {
    theme: 'bootstrap-5',
    width: 'style',
    dropdownAutoWidth: true,
  };
  let select2GuardsBound = false;

  function decodeJsonAttribute(value) {
    if (!value) return [];
    let raw = value;
    try {
      return JSON.parse(raw);
    } catch (error) {
      try {
        raw = raw.replace(/&quot;/g, '"');
        return JSON.parse(raw);
      } catch (innerError) {
        return [];
      }
    }
  }

  function readJsonScript(id) {
    const el = document.getElementById(id);
    if (!el) return null;
    try {
      return JSON.parse(el.textContent || 'null');
    } catch (e) {
      return null;
    }
  }

  function resolveContext(page) {
    const globalContext = window.DJANGO_CONTEXT || {};

    const scriptTanques = readJsonScript('povoamento-tanques-json');
    const scriptFases = readJsonScript('povoamento-fases-json');
    const scriptLinhas = readJsonScript('povoamento-linhas-json');

    const ctx = {
      ...globalContext,
      tanques: Array.isArray(scriptTanques) ? scriptTanques : [],
      fases: Array.isArray(scriptFases) ? scriptFases : [],
      linhas: Array.isArray(scriptLinhas) ? scriptLinhas : [],
    };

    window.DJANGO_CONTEXT = ctx;
    return ctx;
  }

  function hasSelect2() {
    return Boolean(window.jQuery && window.jQuery.fn && window.jQuery.fn.select2);
  }

  function buildDropdownParent() {
    return window.jQuery('body');
  }

  function bindSelect2Guards() {
    if (!hasSelect2() || select2GuardsBound) return;
    select2GuardsBound = true;
    window.jQuery(document)
      .off('mousedown.povoamento')
      .on('mousedown.povoamento', '.select2-container--open .select2-dropdown', (event) => {
        event.stopPropagation();
      });
  }

  function applySelect2($elements, extraConfig = {}) {
  if (!hasSelect2() || !$elements || !$elements.length) return;

  function getDropdownClasses() {
    let classes = 'select2-dropdown-custom ';
    if (document.documentElement.classList.contains('dark')) classes += 'select2-dropdown-dark';
    return classes;
  }

  const config = {
    theme: 'bootstrap-5',
    width: 'resolve',
    dropdownAutoWidth: true,
    dropdownParent: buildDropdownParent(),     // usa seu helper
    dropdownCssClass: getDropdownClasses(),
    ...extraConfig
  };

  $elements.each(function () {
    const $el = window.jQuery(this);
    $el.select2(config);

    $el.off('select2:open.povoamento').on('select2:open.povoamento', () => {
      const $dd = $el.data('select2').$dropdown;
      if (!$dd || !$dd.length) return;

      // força abrir para baixo
      $dd.removeClass('select2-dropdown--above').addClass('select2-dropdown--below');

      // largura ~15% maior que o campo, com limites de viewport
      const rect = this.getBoundingClientRect();
      const vw = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

      const baseWidth  = rect.width;                 // largura do <select>
      const growWidth  = Math.round(baseWidth * 1.15); // +15%
      const spaceRight = vw - rect.left - 8;         // espaço útil até a borda direita

      // não deixa menor que o campo, nem maior do que cabe na direita
      const desired = Math.max(baseWidth, Math.min(growWidth, spaceRight));

      $dd.css({
        width:     desired + 'px',
        maxWidth:  desired + 'px',
        minWidth:  baseWidth + 'px'
      });
    });
  });
}


  function sanitizeOrigem(tipoOrigemValor) {
    return (tipoOrigemValor || '')
      .toUpperCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^A-Z0-9]/g, '')
      .slice(0, 3) || 'OR';
  }

  function generateGrupoOrigem(tipoOrigemValor) {
    const now = new Date();
    const mes = String(now.getMonth() + 1).padStart(2, '0');
    const ano = String(now.getFullYear()).slice(-2);
    const origemPrefix = sanitizeOrigem(tipoOrigemValor);
    return `${origemPrefix}${mes}${ano}`;
  }

  async function verificarLoteAtivo(tanqueId) {
    if (!tanqueId) return null;

    try {
        const response = await fetchWithCreds(`/producao/api/tanque/${tanqueId}/lote-ativo/`);
        if (!response.ok) {
            return null;
        }
        const data = await response.json();
        if (data?.success && data.lote) {
            return data.lote; // Retorna o objeto completo do lote
        }
        return null;
    } catch (error) {
        return null;
    }
  }

  function validarAntesDeAdicionar(tipoTanqueSelect, curvaSelect, tanqueSelect) {
    if (!tanqueSelect?.value) {
      mostrarMensagem('warning', 'Selecione um tanque.');
      return false;
    }
    if (tipoTanqueSelect?.value === 'Tanque Vazio' && !curvaSelect?.value) {
      mostrarMensagem('warning', 'Selecione a Curva de Crescimento.');
      return false;
    }
    return true;
  }

  async function adicionarLinha({
    tipoTanqueSelect,
    tipoOrigemSelect,
    curvaSelect,
    tanqueSelect,
    listagemBody,
    emptyState,
    totaisRefs,
  }) {
    if (
      !validarAntesDeAdicionar(
        tipoTanqueSelect,
        curvaSelect,
        tanqueSelect,
      )
    ) {
      return;
    }

    const now = new Date();
    const linhaId = `row-${now.getTime()}`;
    const fases = window.DJANGO_CONTEXT?.fases || [];
    const linhas = window.DJANGO_CONTEXT?.linhas || [];

    const faseOptions = fases.map((fase) => `<option value="${fase.pk}">${fase.nome}</option>`).join('');
    const linhaOptions = linhas.map((linha) => `<option value="${linha.pk}">${linha.nome}</option>`).join('');

    // --- Lógica de Reforço vs. Novo Lote ---
    const isReforco = tipoTanqueSelect.options[tipoTanqueSelect.selectedIndex].value === 'POVOADO';
    const loteAtivo = isReforco ? await verificarLoteAtivo(tanqueSelect.value) : null;

    const curvaIdParaLinha = isReforco ? (loteAtivo?.curva_id || '') : (curvaSelect.value || '');
    const curvaTexto = isReforco 
        ? (loteAtivo?.curva_nome || '—') 
        : (curvaSelect.value ? curvaSelect.options[curvaSelect.selectedIndex].text : '—');

    const nomeLoteValor = loteAtivo ? loteAtivo.nome : '';
    const nomeLoteReadonly = loteAtivo ? 'readonly' : '';
    
    const faseIdSelecionada = loteAtivo ? loteAtivo.fase_id : '';
    const faseDisabled = loteAtivo ? 'disabled' : '';

    const novaLinhaHTML = `
      <tr id="${linhaId}" data-tanque-id="${tanqueSelect.value}" data-curva-id="${curvaIdParaLinha}">
        <td><button class="btn btn-sm btn-icon-no-focus" data-action="desfazer" type="button" title="Excluir linha"><i class="bi bi-trash3 text-danger"></i></button></td>
        <td>${tanqueSelect.options[tanqueSelect.selectedIndex].text}</td>
        <td>${generateGrupoOrigem(tipoOrigemSelect?.value)}</td>
        <td>${curvaTexto}</td>
        <td><input type="date" class="form-control form-control-sm" data-field="data_lancamento" value="${now.toISOString().slice(0, 10)}"></td>
        <td><input type="text" class="form-control form-control-sm" data-field="nome_lote" value="${nomeLoteValor}" ${nomeLoteReadonly}></td>
        <td><input type="number" class="form-control form-control-sm" data-field="quantidade" min="0" step="1"></td>
        <td><input type="number" class="form-control form-control-sm" data-field="peso_medio" min="0" step="0.1"></td>
        <td><div class="select2-wrapper"><select class="form-select form-select-sm select2-povoamento" data-field="fase_id" ${faseDisabled}>${faseOptions}</select></div></td>
        <td><div class="select2-wrapper"><select class="form-select form-select-sm select2-povoamento" data-field="linha_id">${linhaOptions}</select></div></td>
        <td><input type="text" class="form-control form-control-sm" placeholder="Ex.: B1, B2" data-field="tamanho"></td>
      </tr>
    `;

    listagemBody.insertAdjacentHTML('beforeend', novaLinhaHTML);
    const novaLinha = document.getElementById(linhaId);

    // Pré-seleciona a fase se for um reforço
    if (loteAtivo && faseIdSelecionada) {
        const faseSelect = novaLinha.querySelector('[data-field="fase_id"]');
        faseSelect.value = faseIdSelecionada;
    }

    if (hasSelect2()) {
      applySelect2(window.jQuery(`#${linhaId} ${SELECT2_SELECTOR}`));
    }

    atualizarEstadoListagem(listagemBody, emptyState);
    recalcularTotais(listagemBody, totaisRefs);
  }

  function validarLinhas(listagemBody, tipoTanqueAtual) {
    const erros = [];
    listagemBody.querySelectorAll('tr').forEach((linha, index) => {
      const ordem = index + 1;
      const findValue = (selector) => linha.querySelector(selector)?.value?.trim();
      const quantidade = Number(findValue('[data-field="quantidade"]')) || 0;
      const pesoMedio = Number(findValue('[data-field="peso_medio"]')) || 0;
      const fase = findValue('[data-field="fase_id"]');
      const linhaProducao = findValue('[data-field="linha_id"]');
      const curva = linha.dataset.curvaId;

      if (quantidade <= 0) erros.push(`Linha ${ordem}: quantidade inválida.`);
      if (pesoMedio <= 0) erros.push(`Linha ${ordem}: peso médio inválido.`);
      if (!fase) erros.push(`Linha ${ordem}: selecione a fase.`);
      if (!linhaProducao) erros.push(`Linha ${ordem}: selecione a linha.`);
      if (tipoTanqueAtual === 'Tanque Vazio' && !curva) erros.push(`Linha ${ordem}: curva obrigatória.`);
    });

    if (erros.length) {
      mostrarMensagem('danger', erros.join('<br>'));
    }
    return erros.length === 0;
  }

  function obterTotaisRefs(page) {
    return {
      linhas: page.querySelector('[data-total="linhas"]'),
      peixes: page.querySelector('[data-total="peixes"]'),
      peso: page.querySelector('[data-total="peso"]'),
    };
  }

  function recalcularTotais(listagemBody, totaisRefs) {
    if (!listagemBody) return;
    let linhas = 0;
    let peixes = 0;
    let peso = 0;

    listagemBody.querySelectorAll('tr').forEach((linha) => {
      linhas += 1;
      const quantidade = Number(linha.querySelector('[data-field="quantidade"]')?.value || 0);
      const pesoMedio = Number(linha.querySelector('[data-field="peso_medio"]')?.value || 0);
      peixes += quantidade;
      peso += (quantidade * pesoMedio) / 1000;
    });

    const { linhas: linhasEl, peixes: peixesEl, peso: pesoEl } = totaisRefs || {};
    const formatter = new Intl.NumberFormat('pt-BR');

    if (linhasEl) linhasEl.textContent = String(linhas);
    if (peixesEl) peixesEl.textContent = formatter.format(peixes);
    if (pesoEl) pesoEl.textContent = `${peso.toFixed(1)} kg`;

    return { linhas, peixes, pesoKg: peso };
  }

  function atualizarEstadoListagem(listagemBody, emptyState) {
    if (!emptyState) return;
    const hasRows = Boolean(listagemBody?.querySelector('tr'));
    emptyState.classList.toggle('d-none', hasRows);
  }

  function limparListagem(listagemBody, emptyState, totaisRefs) {
    if (!listagemBody) return;
    listagemBody.innerHTML = '';
    atualizarEstadoListagem(listagemBody, emptyState);
    recalcularTotais(listagemBody, totaisRefs);
  }

  async function processarPovoamentos({
    tipoTanqueSelect,
    listagemBody,
    processarBtn,
    emptyState,
    totaisRefs,
  }) {
    const linhas = Array.from(listagemBody.querySelectorAll('tr'));
    if (!linhas.length) {
      mostrarMensagem('warning', 'Adicione pelo menos uma linha para processar.');
      return;
    }

    if (!validarLinhas(listagemBody, tipoTanqueSelect.value)) {
      return;
    }

    const payload = {
      povoamentos: linhas.map((linha) => ({
        tipo_tanque: tipoTanqueSelect.options[tipoTanqueSelect.selectedIndex].value,
        curva_id: linha.dataset.curvaId || null,
        tanque_id: linha.dataset.tanqueId,
        grupo_origem: linha.cells[2]?.textContent?.trim() || null,
        data_lancamento: linha.querySelector('[data-field="data_lancamento"]').value || null,
        nome_lote: linha.querySelector('[data-field="nome_lote"]').value || null,
        quantidade: parseFloat(linha.querySelector('[data-field="quantidade"]').value) || null,
        peso_medio: parseFloat(linha.querySelector('[data-field="peso_medio"]').value) || null,
        fase_id: parseInt(linha.querySelector('[data-field="fase_id"]').value, 10) || null,
        tamanho: linha.querySelector('[data-field="tamanho"]').value || null,
        linha_id: parseInt(linha.querySelector('[data-field="linha_id"]').value, 10) || null,
      })),
    };

    processarBtn.disabled = true;
    const originalLabel = processarBtn.innerHTML;
    processarBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Processando...';

    try {
      const response = await fetchWithCreds('/producao/povoamento/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await response.json().catch(() => ({}));

      if (!response.ok) {
        mostrarMensagem('danger', result?.message || 'Falha ao processar os povoamentos.');
        return;
      }

      mostrarMensagem('success', result?.message || 'Povoamentos processados com sucesso.');
      limparListagem(listagemBody, emptyState, totaisRefs);
    } catch (error) {
      mostrarMensagem('danger', 'Ocorreu um erro de comunicação com o servidor.');
    } finally {
      processarBtn.disabled = false;
      processarBtn.innerHTML = originalLabel;
    }
  }

  function bindHistorico(buscarBtn, historicoBody) {
    if (!buscarBtn || !historicoBody) return;
    buscarBtn.addEventListener('click', async (event) => {
      event.preventDefault();
      const inicial = document.querySelector('[data-filter="data_inicial"]').value;
      const final = document.querySelector('[data-filter="data_final"]').value;
      const status = document.querySelector('[data-filter="status"]').value;
      const url = new URL('/producao/api/povoamento/historico/', window.location.origin);
      if (inicial) url.searchParams.append('data_inicial', inicial);
      if (final) url.searchParams.append('data_final', final);
      if (status) url.searchParams.append('status', status);

      try {
        const response = await fetchWithCreds(url.toString());
        const data = await response.json();
        historicoBody.innerHTML = data?.success
          ? data.historico.map((item) => `
              <tr>
                <td>${item.id}</td>
                <td>${item.data}</td>
                <td>${item.lote}</td>
                <td>${item.tanque}</td>
                <td>${item.quantidade}</td>
                <td>${item.peso_medio}</td>
                <td>${item.tipo_evento}</td>
              </tr>
            `).join('')
          : '';
      } catch (error) {
        mostrarMensagem('danger', 'Não foi possível carregar o histórico.');
      }
    });
  }


  // === Ajuste: atualizarOpcoesTanque usando id/pk e data-role ===
function atualizarOpcoesTanque(tipoTanqueSelect, tanqueSelect) {
  if (!tanqueSelect) return;

  const tipo = (tipoTanqueSelect?.value || '').trim(); // 'VAZIO' | 'POVOADO'
  const tanques = Array.isArray(window.DJANGO_CONTEXT?.tanques) ? window.DJANGO_CONTEXT.tanques : [];

  const filtrados = tanques.filter(t =>
    tipo === 'VAZIO' ? !t.tem_lote_ativo : !!t.tem_lote_ativo
  );

  tanqueSelect.innerHTML = [
    '<option value="">Selecione...</option>',
    ...filtrados.map(t => {
      const tid = getObjId(t);
      return `<option value="${tid}">${t.nome}</option>`;
    })
  ].join('');

  // Se estiver com select2, força refresh visual
  if (window.jQuery && window.jQuery(tanqueSelect).data('select2')) {
    window.jQuery(tanqueSelect).trigger('change.select2');
  }
}


  // === Ajuste: initPovoamentoLotes encontrando selects por data-role e fallback por id ===
function initPovoamentoLotes() {
  const page = document.querySelector('[data-page="povoamento-lotes"], #povoamento-page, body');
  if (!page) return;

  const tipoTanqueSelect =
    document.querySelector('[data-role="tipo-tanque"]') ||
    document.getElementById('tipo-tanque') ||
    document.getElementById('id_tipo_tanque');

  const tanqueSelect =
    document.querySelector('[data-role="tanque"]') ||
    document.getElementById('tanque') ||
    document.getElementById('id_tanque');

  if (!tipoTanqueSelect || !tanqueSelect) {
    console.warn('[povoamento] Selects não encontrados:', { tipoTanqueSelect, tanqueSelect });
    return;
  }

  // popula no load
  atualizarOpcoesTanque(tipoTanqueSelect, tanqueSelect);

  // change do tipo tanque => repopula
  tipoTanqueSelect.addEventListener('change', () => {
    atualizarOpcoesTanque(tipoTanqueSelect, tanqueSelect);
    atualizarChips(''); // limpa chips ao trocar tipo
  });

  // change do tanque => chips
  tanqueSelect.addEventListener('change', () => {
    atualizarChips(tanqueSelect.value);
  });

  // se já houver valor inicial
  if (tanqueSelect.value) atualizarChips(tanqueSelect.value);
}



  // --- Auto-inicialização do Módulo ---

  function initializeWhenReady() {
    // Garante que só executa na página certa.
    const page = document.querySelector(PAGE_SELECTOR);
    if (page) {
      initPovoamentoLotes();
    }
  }

  // Espera o DOM estar completamente carregado para executar em um hard-refresh.
  // Isso resolve a condição de corrida.
  document.addEventListener('DOMContentLoaded', initializeWhenReady);

  // O listener para 'ajaxContentLoaded' é mantido para funcionar com a navegação AJAX do sistema.
  document.addEventListener('ajaxContentLoaded', initializeWhenReady);

})();
