(function () {
  function sanitize(v) {
    if (!v) return "";
    const s = String(v).trim().toLowerCase();
    return (s === "todas" || s === "todos") ? "" : v;
  }

  async function carregarMortalidade() {
    const unidade = sanitize(document.querySelector("#filtro-unidade")?.value);
    const linha   = sanitize(document.querySelector("#filtro-linha")?.value);
    const fase    = sanitize(document.querySelector("#filtro-fase")?.value);
    const data    = document.querySelector("#filtro-data")?.value;

    const params = new URLSearchParams();
    if (unidade) params.set("unidade", unidade);
    if (linha)   params.set("linha_producao", linha);
    if (fase)    params.set("fase", fase);
    if (data)    params.set("data", data);

    const url = `/producao/api/eventos/mortalidade/?${params.toString()}`;
    const tbody = document.querySelector("#tabela-mortalidade tbody");
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="99"><span class="badge bg-primary">Carregando dados...</span></td></tr>`;
    }

    const resp = await fetch(url, { credentials: "same-origin", headers: { "X-Requested-With": "XMLHttpRequest" } });
    if (!resp.ok) {
      console.error("Falha ao carregar mortalidade:", resp.status, await resp.text());
      if (tbody) tbody.innerHTML = `<tr><td colspan="99"><span class="badge bg-danger">Erro ao carregar</span></td></tr>`;
      return;
    }
    const json = await resp.json();
    renderTabelaMortalidade(json.results || []);
  }

  function renderTabelaMortalidade(items) {
    const tbody = document.querySelector("#tabela-mortalidade tbody");
    if (!tbody) return;
    if (!items.length) {
      tbody.innerHTML = `<tr><td colspan="99">Nenhum lote ativo na data.</td></tr>`;
      return;
    }
    const rows = items.map(it => `
      <tr data-lote="${it.lote_id}">
        <td>${it.tanque}</td>
        <td>${it.lote}</td>
        <td>${it.data_inicio}</td>
        <td class="text-end">${it.qtd_atual}</td>
        <td class="text-end">${it.peso_medio_g}</td>
        <td class="text-end">${it.biomassa_kg}</td>
        <td class="text-end"><input type="number" min="0" class="form-control form-control-sm input-mort" value="${it.qtd_mortalidade}"></td>
        <td class="text-end">${it.peso_medio_dia_g ?? "-"}</td>
        <td class="text-end">0.00</td>
      </tr>
    `).join("");
    tbody.innerHTML = rows;
  }

  document.addEventListener("DOMContentLoaded", () => {
    // carregamento inicial
    carregarMortalidade();

    // recarregar ao trocar filtros
    ["#filtro-unidade", "#filtro-linha", "#filtro-fase", "#filtro-data"].forEach(sel => {
      const el = document.querySelector(sel);
      if (el) el.addEventListener("change", carregarMortalidade);
    });

    // se estiver usando abas bootstrap:
    document.querySelectorAll('[data-bs-toggle="tab"]').forEach(el => {
      el.addEventListener("shown.bs.tab", (e) => {
        const target = e.target?.getAttribute("data-bs-target");
        if (target === "#pane-mortalidade") carregarMortalidade();
      });
    });
  });
})();