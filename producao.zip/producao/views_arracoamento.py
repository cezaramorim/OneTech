# -*- coding: utf-8 -*-
import json
from datetime import date, datetime, timedelta
from decimal import Decimal
from django.db.models import Sum, Q, F, Value, Case, When
from django.db.models.fields import DecimalField
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required, permission_required
from django.db import transaction
from django.utils import timezone
import logging

from .models import Lote, LoteDiario, ArracoamentoSugerido, ArracoamentoRealizado, LinhaProducao, EventoManejo, ParametroAmbientalDiario
from .utils import sugerir_racao_para_dia, reprojetar_ciclo_de_vida, _apurar_quantidade_real_no_dia, recalcular_lote_diario_real, obter_base_sugerida, fator_resposta_biologica, calcular_fator_ambiente
# Importa as novas funções de cálculo padronizadas
from .utils_uom import calc_biomassa_kg, calc_fcr, g_to_kg, q2, q3
from produto.models import Produto # Importado no topo para evitar 'cannot access local variable' e garantir disponibilidade global.


@login_required
@require_http_methods(["GET"])
@permission_required('producao.view_lote', raise_exception=True)
def api_sugestoes_arracoamento(request):
    # ... (código já refatorado, mantido como está)
    logging.info("Iniciando api_sugestoes_arracoamento.")
    try:
        data_str = request.GET.get('data', date.today().isoformat())
        data_alvo = datetime.strptime(data_str, '%Y-%m-%d').date()
        linha_producao_id = request.GET.get('linha_producao_id')
    except (ValueError, TypeError):
        return JsonResponse({'success': False, 'message': 'Formato de data inválido. Use AAAA-MM-DD.'}, status=400)

    erros = []
    
    # Lógica de anotação para calcular a quantidade atual no banco de dados
    base_query = Lote.objects.filter(
        ativo=True,
        data_povoamento__lte=data_alvo
    )

    # Anota as entradas e saídas totais para cada lote
    annotated_lotes = base_query.annotate(
        total_entradas=Sum(
            Case(
                When(Q(eventos_manejo__tipo_evento__nome='Povoamento') | Q(eventos_manejo__tipo_movimento='Entrada'), then='eventos_manejo__quantidade'),
                default=Value(0),
                output_field=DecimalField()
            )
        ),
        total_saidas=Sum(
            Case(
                When(Q(eventos_manejo__tipo_evento__nome__in=['Mortalidade', 'Despesca']) | Q(eventos_manejo__tipo_movimento='Saída'), then='eventos_manejo__quantidade'),
                default=Value(0),
                output_field=DecimalField()
            )
        )
    )

    # Calcula a quantidade atual e filtra os lotes elegíveis
    lotes_elegibles = annotated_lotes.annotate(
        quantidade_atual_calculada=F('total_entradas') - F('total_saidas')
    ).filter(
        quantidade_atual_calculada__gt=0
    ).select_related('tanque_atual__linha_producao', 'curva_crescimento')

    if linha_producao_id:
        lotes_elegibles = lotes_elegibles.filter(tanque_atual__linha_producao_id=linha_producao_id)

    with transaction.atomic():
        for lote in lotes_elegibles:
            # Tenta obter o LoteDiario para o dia alvo
            lote_diario, created = LoteDiario.objects.get_or_create(
                lote=lote,
                data_evento=data_alvo,
            )

            # Se for um novo registro diário, precisamos preencher suas bases
            if created:
                # Busca o dia anterior para usar como base
                dia_anterior = data_alvo - timedelta(days=1)
                lote_diario_anterior = LoteDiario.objects.filter(lote=lote, data_evento=dia_anterior).first()

                if lote_diario_anterior:
                    # A base para hoje são os valores REAIS de ontem
                    base_qtd = lote_diario_anterior.quantidade_real
                    base_peso = lote_diario_anterior.peso_medio_real
                else:
                    # Se não há ontem, é o primeiro dia. A base é o próprio lote.
                    base_qtd = lote.quantidade_inicial
                    base_peso = lote.peso_medio_inicial

                # Garante que não estamos trabalhando com valores nulos
                lote_diario.quantidade_inicial = base_qtd if base_qtd is not None else Decimal('0')
                lote_diario.peso_medio_inicial = base_peso if base_peso is not None else Decimal('0')
                lote_diario.biomassa_inicial = calc_biomassa_kg(lote_diario.quantidade_inicial, lote_diario.peso_medio_inicial)
                
                # Salva as bases corretas
                lote_diario.save()

            # Com o lote_diario garantido e com bases corretas, chamamos a nova função
            resultado_sugestao = sugerir_racao_para_dia(lote_diario)
            
            if 'error' not in resultado_sugestao:
                sugestao, created_sug = ArracoamentoSugerido.objects.get_or_create(
                    lote_diario=lote_diario,
                    defaults={
                        'produto_racao': resultado_sugestao['produto_racao'],
                        'quantidade_kg': resultado_sugestao['quantidade_kg'],
                        'status': 'Pendente'
                    }
                )
                if not created_sug and sugestao.status == 'Pendente':
                    sugestao.produto_racao = resultado_sugestao['produto_racao']
                    sugestao.quantidade_kg = resultado_sugestao['quantidade_kg']
                    sugestao.save()
            else:
                erros.append(f"Lote {lote.nome}: {resultado_sugestao['error']}")

        sugestoes_qs = ArracoamentoSugerido.objects.filter(
            lote_diario__data_evento=data_alvo
        ).select_related(
            'lote_diario__lote',
            'lote_diario__lote__tanque_atual__linha_producao',
            'produto_racao'
        ).prefetch_related('lote_diario__realizacoes')
    
    if linha_producao_id:
        sugestoes_qs = sugestoes_qs.filter(lote_diario__lote__tanque_atual__linha_producao_id=linha_producao_id)

    todas_sugestoes = sorted(list(sugestoes_qs), key=lambda s: (s.lote_diario.lote.tanque_atual.sequencia if s.lote_diario.lote.tanque_atual else 999999))

    # --- Ambiente por Fase (1 query, sem N+1) ---
    fase_ids = set()
    for s in todas_sugestoes:
        fase = getattr(s.lote_diario.lote, 'fase_producao', None)
        if fase:
            fase_ids.add(fase.id)

    ambiente_por_fase = {}
    if fase_ids:
        qs_amb = ParametroAmbientalDiario.objects.filter(
            data=data_alvo,
            fase_id__in=list(fase_ids)
        )
        ambiente_por_fase = {a.fase_id: a for a in qs_amb}

    sugestoes_serializadas = []
    for s in todas_sugestoes:
        realizado_id = s.lote_diario.realizacoes.order_by('-data_realizacao').first().id if s.status == 'Aprovado' and s.lote_diario.realizacoes.exists() else None
        racao_realizada_obj = s.lote_diario.racao_realizada

        fase = getattr(s.lote_diario.lote, 'fase_producao', None)
        param_amb = ambiente_por_fase.get(fase.id) if fase else None
        amb = calcular_fator_ambiente(param_amb)

        # Passo 4: fator_manejo fica neutro (1.00). Depois (Passo 5/6) vira configurável.
        fator_manejo = Decimal('1.00')

        qtd_sugerida = Decimal(s.quantidade_kg or 0)
        qtd_ajustada = (qtd_sugerida * amb['fator_ambiente'] * fator_manejo) if qtd_sugerida > 0 else Decimal('0')

        # --- PASSO 5: Persistir snapshot da sugestão ajustada no LoteDiario ---
        ld = s.lote_diario

        # Base (curva)
        ld.racao_sugerida = s.produto_racao
        ld.racao_sugerida_kg = qtd_sugerida

        # Ajustada (ambiente/manejo)
        ld.racao_sugerida_ajustada_kg = qtd_ajustada
        ld.fator_ambiente = amb['fator_ambiente']
        ld.fator_manejo = fator_manejo

        # Snapshot ambiental (médias e variação)
        if param_amb:
            ld.od_medio = param_amb.od_medio
            ld.temp_media = param_amb.temp_media
            ld.temp_min = param_amb.temp_min
            ld.temp_max = param_amb.temp_max
            ld.variacao_termica = param_amb.variacao_termica
        else:
            ld.od_medio = None
            ld.temp_media = None
            ld.temp_min = None
            ld.temp_max = None
            ld.variacao_termica = None

        ld.save(update_fields=[
            'racao_sugerida', 'racao_sugerida_kg',
            'racao_sugerida_ajustada_kg', 'fator_ambiente', 'fator_manejo',
            'od_medio', 'temp_media', 'temp_min', 'temp_max', 'variacao_termica'
        ])

        tem_real = s.lote_diario.realizacoes.exists()
        status_front = 'Aprovado' if tem_real else 'Pendente'
        sugestoes_serializadas.append({
            'sugestao_id': s.id,
            'realizado_id': realizado_id,
            'lote_id': s.lote_diario.lote.id,
            'fase_id': s.lote_diario.lote.fase_producao.id if s.lote_diario.lote.fase_producao else None,
            'fase_nome': s.lote_diario.lote.fase_producao.nome if s.lote_diario.lote.fase_producao else 'N/A',
            'lote_nome': s.lote_diario.lote.nome,
            'tanque_nome': s.lote_diario.lote.tanque_atual.nome if s.lote_diario.lote.tanque_atual else 'N/A',
            'lote_quantidade_atual': f"{s.lote_diario.quantidade_inicial:.2f}" if s.lote_diario.quantidade_inicial is not None else "0.00",
            'lote_peso_medio_atual': f"{s.lote_diario.peso_medio_inicial:.2f}" if s.lote_diario.peso_medio_inicial is not None else "0.00",
            'lote_linha_producao': s.lote_diario.lote.tanque_atual.linha_producao.nome if s.lote_diario.lote.tanque_atual and s.lote_diario.lote.tanque_atual.linha_producao else 'N/A',
            'lote_sequencia': s.lote_diario.lote.tanque_atual.sequencia if s.lote_diario.lote.tanque_atual else 'N/A',
            'produto_racao_id': s.produto_racao.id if s.produto_racao else None,
            'produto_racao_nome': s.produto_racao.nome if s.produto_racao else 'N/A',
            'racao_realizada_id': racao_realizada_obj.id if racao_realizada_obj else None, # Adicionado
            'quantidade_kg': f"{s.quantidade_kg:.3f}",
            'quantidade_kg_ajustada': f"{qtd_ajustada:.3f}",
            'fator_ambiente': f"{amb['fator_ambiente']:.2f}" if amb['fator_ambiente'] is not None else None,
            'od_medio': f"{amb['od_medio']:.2f}" if amb['od_medio'] is not None else None,
            'temp_media': f"{amb['temp_media']:.2f}" if amb['temp_media'] is not None else None,
            'variacao_termica': f"{amb['variacao_termica']:.2f}" if amb['variacao_termica'] is not None else None,
            'quantidade_realizada_kg': f"{s.lote_diario.racao_realizada_kg:.3f}" if s.lote_diario.racao_realizada_kg is not None else "",
            'status': status_front,
        })

    # --- NOVA LÓGICA DE VERIFICAÇÃO DE PENDÊNCIAS ---
    # Identifica dias "pulados" (sem aprovação) entre a última aprovação e a data alvo para cada lote.
    pendentes_anteriores_qs = LoteDiario.objects.filter(
        lote__ativo=True,
        data_evento__lt=data_alvo
    ).filter(
        realizacoes__isnull=True
    ).values_list('data_evento', flat=True).distinct().order_by('data_evento')

    pending_previous_approval_dates = list(pendentes_anteriores_qs)
    formatted_pending_dates = [d.strftime("%d/%m/%Y") for d in pending_previous_approval_dates]

    return JsonResponse({
        'success': True,
        'sugestoes': sugestoes_serializadas,
        'erros': erros,
        'has_pending_previous_approvals': bool(pending_previous_approval_dates),
        'pending_previous_approval_dates': formatted_pending_dates
    })

@login_required
@require_http_methods(["POST"])
@permission_required('producao.change_arracoamentosugerido', raise_exception=True)
def api_aprovar_arracoamento(request):
    try:
        data = json.loads(request.body)
        sugestao_id = data.get('sugestao_id')
        racao_realizada_id = data.get('racao_realizada_id')
        observacoes = data.get('observacoes', '')

        with transaction.atomic():
            sugestao = ArracoamentoSugerido.objects.select_related('lote_diario__lote', 'produto_racao').get(id=sugestao_id)
            
            if sugestao.status == 'Aprovado':
                return JsonResponse({'success': False, 'message': 'Esta sugestão já foi aprovada.'}, status=400)

            # Lógica para determinar a quantidade a ser usada
            quantidade_real_kg_str = data.get('quantidade_real_kg')
            quantidade_a_usar = None

            if quantidade_real_kg_str and str(quantidade_real_kg_str).strip():
                try:
                    valor_decimal = Decimal(quantidade_real_kg_str)
                    if valor_decimal > 0:
                        quantidade_a_usar = q3(valor_decimal)
                except (ValueError, TypeError):
                    pass  # Ignora valores não numéricos, vai usar o fallback

            if quantidade_a_usar is None:
                # Fallback para a quantidade sugerida ajustada se a entrada do usuário for vazia ou inválida
                quantidade_a_usar = sugestao.lote_diario.racao_sugerida_ajustada_kg

            # Validação final
            if not quantidade_a_usar or quantidade_a_usar <= 0:
                return JsonResponse({'success': False, 'message': 'A quantidade real ou sugerida deve ser um número positivo.'}, status=400)

            lote = Lote.objects.select_for_update().get(pk=sugestao.lote_diario.lote.pk)
            lote_diario = sugestao.lote_diario
            ld = lote_diario

            # Determina qual ração usar: a escolhida pelo usuário ou a sugerida como padrão
            racao_a_ser_usada = sugestao.produto_racao
            if racao_realizada_id:
                try:
                    racao_a_ser_usada = Produto.objects.get(pk=racao_realizada_id)
                except Produto.DoesNotExist:
                    return JsonResponse({'success': False, 'message': f'A ração escolhida com ID {racao_realizada_id} não foi encontrada.'}, status=404)

            sugestao.status = 'Aprovado'
            sugestao.save(update_fields=['status'])

            ArracoamentoRealizado.objects.create(
                lote_diario=lote_diario,
                data_evento=lote_diario.data_evento,
                produto_racao=racao_a_ser_usada,
                quantidade_kg=quantidade_a_usar,  # Usa a quantidade determinada
                data_realizacao=timezone.now(),
                usuario_lancamento=request.user,
                observacoes=observacoes
            )

            # --- Lógica de Decréscimo de Estoque ---
            from django.db.models import F
            try:
                Produto.objects.filter(pk=racao_a_ser_usada.pk).update(
                    quantidade_saidas=F('quantidade_saidas') + quantidade_a_usar
                )
                racao_a_ser_usada.refresh_from_db()
                racao_a_ser_usada.save()
                logging.info(f"Estoque do produto '{racao_a_ser_usada.nome}' atualizado. Saídas incrementadas em {quantidade_a_usar} kg.")
            except Exception as e:
                logging.error(f"Erro ao atualizar estoque do produto {racao_a_ser_usada.id}: {e}")
                raise Exception(f"Falha ao atualizar estoque da ração: {e}")

            # Define a quantidade inicial do dia com base no dia anterior ou no lote
            dia_anterior = lote_diario.data_evento - timedelta(days=1)
            lote_diario_anterior = LoteDiario.objects.filter(lote=lote, data_evento=dia_anterior).first()
            
            quantidade_inicial_dia = lote.quantidade_inicial
            if lote_diario_anterior and lote_diario_anterior.quantidade_real is not None:
                quantidade_inicial_dia = lote_diario_anterior.quantidade_real
            lote_diario.quantidade_inicial = quantidade_inicial_dia

            # Apura a quantidade real do dia (inicial +/- eventos do dia)
            lote_diario.quantidade_real = _apurar_quantidade_real_no_dia(lote_diario)
            
            # Define o peso médio inicial do dia
            peso_medio_inicial_dia = lote.peso_medio_inicial
            if lote_diario_anterior and lote_diario_anterior.peso_medio_real is not None:
                peso_medio_inicial_dia = lote_diario_anterior.peso_medio_real
            lote_diario.peso_medio_inicial = peso_medio_inicial_dia
            
            # Define a biomassa inicial do dia
            biomassa_inicial_dia = calc_biomassa_kg(lote_diario.quantidade_inicial, lote_diario.peso_medio_inicial)
            lote_diario.biomassa_inicial = biomassa_inicial_dia

            lote_diario.racao_realizada = racao_a_ser_usada

            lote_diario.save(update_fields=[
                'quantidade_inicial',
                'quantidade_real',
                'peso_medio_inicial',
                'biomassa_inicial',
                'racao_realizada',
            ])

            recalcular_lote_diario_real(ld, request.user)

            proximo_dia = lote_diario.data_evento + timedelta(days=1)
            proximo = LoteDiario.objects.filter(lote=lote, data_evento=proximo_dia).first()
            if proximo:
                proximo.biomassa_inicial    = ld.biomassa_real
                proximo.peso_medio_inicial  = ld.peso_medio_real
                proximo.quantidade_inicial  = ld.quantidade_real
                proximo.save(update_fields=['biomassa_inicial','peso_medio_inicial','quantidade_inicial'])

            reprojetar_ciclo_de_vida(lote, lote_diario.data_evento + timedelta(days=1))

        return JsonResponse({'success': True, 'message': 'Arraçoamento aprovado e registrado com sucesso.'})

    except ArracoamentoSugerido.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Sugestão de arraçoamento não encontrada.'}, status=404)
    except Exception as e:
        logging.exception(f"Erro inesperado ao aprovar arraçoamento: {e}")
        return JsonResponse({'success': False, 'message': f'Erro ao aprovar arraçoamento: {str(e)}'}, status=500)


# --- Funções Restauradas e Refatoradas ---

@login_required
@require_http_methods(["DELETE"])
@permission_required('producao.delete_arracoamentorealizado', raise_exception=True)
@transaction.atomic
def api_delete_arracoamento_realizado(request, pk):
    try:
        obj = ArracoamentoRealizado.objects.select_related('lote_diario__lote').get(pk=pk)
        lote_diario = obj.lote_diario
        lote = lote_diario.lote
        data_evento_revertido = lote_diario.data_evento

        if hasattr(lote_diario, 'sugestao'):
            sugestao = lote_diario.sugestao
            sugestao.status = 'Pendente'
            sugestao.save(update_fields=['status'])

        obj.delete()

        lote_diario.racao_realizada = None
        lote_diario.racao_realizada_kg = None
        lote_diario.gpd_real = None
        lote_diario.gpt_real = None
        lote_diario.conversao_alimentar_real = None
        lote_diario.peso_medio_real = None
        lote_diario.usuario_edicao = None
        lote_diario.save()

        reprojetar_ciclo_de_vida(lote, data_evento_revertido)

        return JsonResponse({'success': True, 'message': 'Lançamento excluído e projeção revertida.'})
    except ArracoamentoRealizado.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Lançamento não encontrado.'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'message': f'Erro ao excluir lançamento: {str(e)}'}, status=500)

@login_required
@require_http_methods(["POST"])
@permission_required('producao.delete_arracoamentorealizado', raise_exception=True)
@transaction.atomic
def api_bulk_delete_arracoamento_realizado(request):
    try:
        data = json.loads(request.body)
        ids = data.get('ids', [])
        if not ids:
            return JsonResponse({'success': False, 'message': 'Nenhum item selecionado para exclusão.'}, status=400)
        
        lotes_afetados = {}
        realizados_para_excluir = ArracoamentoRealizado.objects.filter(id__in=ids).select_related('lote_diario__lote')

        for obj in realizados_para_excluir:
            lote_diario = obj.lote_diario
            if hasattr(lote_diario, 'sugestao'):
                lote_diario.sugestao.status = 'Pendente'
                lote_diario.sugestao.save(update_fields=['status'])

            lote_diario.racao_realizada = None
            lote_diario.racao_realizada_kg = None
            lote_diario.save()

            lote_id = lote_diario.lote.id
            data_evento = lote_diario.data_evento
            if lote_id not in lotes_afetados or data_evento < lotes_afetados[lote_id]:
                lotes_afetados[lote_id] = data_evento

        deleted_count, _ = realizados_para_excluir.delete()

        for lote_id, data_inicio in lotes_afetados.items():
            lote = Lote.objects.get(id=lote_id)
            reprojetar_ciclo_de_vida(lote, data_inicio)

        return JsonResponse({'success': True, 'message': f'{deleted_count} lançamento(s) excluído(s) e projeções revertidas.'})
    except json.JSONDecodeError:
        return JsonResponse({'success': False, 'message': 'Requisição JSON inválida.'}, status=400)
    except Exception as e:
        return JsonResponse({'success': False, 'message': f'Erro ao excluir lançamentos: {str(e)}'}, status=500)

@login_required
@require_http_methods(["POST"])
@permission_required('producao.change_arracoamentorealizado', raise_exception=True)
@transaction.atomic
def api_update_arracoamento_realizado(request, pk):
    try:
        data = json.loads(request.body)
        obj = ArracoamentoRealizado.objects.select_related('lote_diario__lote').get(pk=pk)
        lote_diario = obj.lote_diario

        obj.quantidade_kg = q3(data.get('quantidade_kg'))

        obj.observacoes = data.get('observacoes', '')
        obj.usuario_edicao = request.user
        obj.data_edicao = timezone.now()
        obj.save()

        # --- INÍCIO DA LÓGICA DE CÁLCULO DE MÉTRICAS REAIS ---
        lote = lote_diario.lote
        lote_diario.data_edicao = timezone.now()
        lote_diario.usuario_edicao = request.user # PASSO 4: Atribui o usuário de edição ao LoteDiario

        # Define a quantidade inicial do dia com base no dia anterior ou no lote
        dia_anterior = lote_diario.data_evento - timedelta(days=1)
        lote_diario_anterior = LoteDiario.objects.filter(lote=lote, data_evento=dia_anterior).first()
        
        quantidade_inicial_dia = lote.quantidade_inicial
        if lote_diario_anterior and lote_diario_anterior.quantidade_real is not None:
            quantidade_inicial_dia = lote_diario_anterior.quantidade_real
        lote_diario.quantidade_inicial = quantidade_inicial_dia

        # Apura a quantidade real do dia (inicial +/- eventos do dia)
        lote_diario.quantidade_real = _apurar_quantidade_real_no_dia(lote_diario)
        
        # Define o peso médio inicial do dia
        peso_medio_inicial_dia = lote.peso_medio_inicial
        if lote_diario_anterior and lote_diario_anterior.peso_medio_real is not None:
            peso_medio_inicial_dia = lote_diario_anterior.peso_medio_real
        lote_diario.peso_medio_inicial = peso_medio_inicial_dia
        
        # Define a biomassa inicial do dia
        biomassa_inicial_dia = calc_biomassa_kg(lote_diario.quantidade_inicial, lote_diario.peso_medio_inicial)
        lote_diario.biomassa_inicial = biomassa_inicial_dia

        ld = lote_diario
        # Mantém o snapshot do LoteDiario alinhado ao lançamento editado
        lote_diario.racao_realizada = obj.produto_racao

        # PASSO 5.2: Chamar a função única de recálculo
        recalcular_lote_diario_real(ld, request.user)

        # --- LÓGICA DE ENCADEAMENTO D -> D+1 ---
        proximo_dia = lote_diario.data_evento + timedelta(days=1)
        proximo = LoteDiario.objects.filter(lote=lote, data_evento=proximo_dia).first()
        if proximo:
            base_bio  = lote_diario.biomassa_real if lote_diario.biomassa_real is not None else lote_diario.biomassa_projetada
            base_peso = lote_diario.peso_medio_real if lote_diario.peso_medio_real is not None else lote_diario.peso_medio_projetado
            base_qtd  = lote_diario.quantidade_real if lote_diario.quantidade_real is not None else lote_diario.quantidade_projetada

            proximo.biomassa_inicial    = base_bio
            proximo.peso_medio_inicial  = base_peso
            proximo.quantidade_inicial  = base_qtd
            proximo.save(update_fields=['biomassa_inicial','peso_medio_inicial','quantidade_inicial'])

        reprojetar_ciclo_de_vida(lote_diario.lote, lote_diario.data_evento + timedelta(days=1))

        return JsonResponse({'success': True, 'message': 'Lançamento atualizado e projeção recalculada.'})
    except ArracoamentoRealizado.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Lançamento não encontrado.'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'message': f'Erro ao atualizar lançamento: {str(e)}'}, status=500)

@login_required
@require_http_methods(["GET"])
@permission_required('producao.view_arracoamentorealizado', raise_exception=True)
def api_get_arracoamento_realizado(request, pk):
    try:
        obj = ArracoamentoRealizado.objects.get(pk=pk)
        data = {
            'id': obj.id,
            'lote_diario_id': obj.lote_diario.id,
            'lote_nome': obj.lote_diario.lote.nome,
            'produto_racao_id': obj.produto_racao.id if obj.produto_racao else None,
            'produto_racao_nome': obj.produto_racao.nome if obj.produto_racao else 'N/A',
            'quantidade_kg': float(obj.quantidade_kg),
            'data_realizacao': (obj.data_realizacao or obj.data_lancamento).isoformat(),
            'observacoes': obj.observacoes,
        }
        return JsonResponse({'success': True, 'data': data})
    except ArracoamentoRealizado.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Lançamento não encontrado.'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'message': f'Erro ao buscar lançamento: {str(e)}'}, status=500)

